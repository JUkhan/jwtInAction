//import sample from 'Scripts/Modules/testModule/sample.js';d

var moduleName='testModule'; 
angular.module(moduleName, []);
export default moduleName;
